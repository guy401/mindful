
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: 'hsl(var(--primary))',
					foreground: 'hsl(var(--primary-foreground))'
				},
				secondary: {
					DEFAULT: 'hsl(var(--secondary))',
					foreground: 'hsl(var(--secondary-foreground))'
				},
				destructive: {
					DEFAULT: 'hsl(var(--destructive))',
					foreground: 'hsl(var(--destructive-foreground))'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				accent: {
					DEFAULT: 'hsl(var(--accent))',
					foreground: 'hsl(var(--accent-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				},
				nutrition: {
					50: '#f0f9f0',
					100: '#dbf1dc',
					200: '#bae3bc',
					300: '#8ecd91',
					400: '#5daf62',
					500: '#3f9144',
					600: '#2d7532',
					700: '#245d29',
					800: '#1f4a23',
					900: '#1c3d1f',
					950: '#0e220f',
				},
				wellness: {
					50: '#f0f7fe',
					100: '#dceefb',
					200: '#c1e0f8',
					300: '#94caf2',
					400: '#61adea',
					500: '#3d8fe0',
					600: '#2872d3',
					700: '#2360c1',
					800: '#214f9e',
					900: '#1f447d',
					950: '#172a4e',
				},
				earth: {
					50: '#f8f7f2',
					100: '#eeeae0',
					200: '#ded7c2',
					300: '#c8bc9c',
					400: '#b3a17a',
					500: '#a48b63',
					600: '#937555',
					700: '#7a5e47',
					800: '#654d3d',
					900: '#544136',
					950: '#2d221d',
				},
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			fontFamily: {
				sans: ['Montserrat', 'sans-serif'],
				serif: ['Playfair Display', 'serif'],
				display: ['Poppins', 'sans-serif'],
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-in': {
					'0%': {
						opacity: '0',
						transform: 'translateY(10px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'fade-out': {
					'0%': {
						opacity: '1',
						transform: 'translateY(0)'
					},
					'100%': {
						opacity: '0',
						transform: 'translateY(10px)'
					}
				},
				'scale-in': {
					'0%': {
						transform: 'scale(0.95)',
						opacity: '0'
					},
					'100%': {
						transform: 'scale(1)',
						opacity: '1'
					}
				},
				'slide-in-bottom': {
					'0%': { 
						transform: 'translateY(30px)',
						opacity: '0'
					},
					'100%': { 
						transform: 'translateY(0)',
						opacity: '1'
					}
				},
				'float': {
					'0%, 100%': {
						transform: 'translateY(0)'
					},
					'50%': {
						transform: 'translateY(-10px)'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-in': 'fade-in 0.5s ease-out',
				'fade-out': 'fade-out 0.5s ease-out',
				'scale-in': 'scale-in 0.3s ease-out',
				'slide-in-bottom': 'slide-in-bottom 0.5s ease-out',
				'float': 'float 6s ease-in-out infinite'
			},
			boxShadow: {
				'soft': '0 5px 30px -15px rgba(0, 0, 0, 0.15)',
				'card': '0 10px 30px -10px rgba(0, 0, 0, 0.1)',
				'card-hover': '0 20px 40px -15px rgba(0, 0, 0, 0.15)',
				'button': '0 5px 15px -5px rgba(61, 143, 224, 0.4)',
			},
			backgroundImage: {
				'hero-pattern': 'linear-gradient(135deg, #f0f9f0 0%, #dceefb 100%)',
				'section-pattern': 'linear-gradient(to top, #f0f7fe 0%, #f0f9f0 100%)',
				'card-pattern': 'linear-gradient(to top, #ffffff 0%, #f8f7f2 100%)',
				'cta-pattern': 'linear-gradient(to right, #3f9144 0%, #2872d3 100%)',
			},
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
