
import React, { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Services from '@/components/Services';
import Expertise from '@/components/Expertise';
import MeetJenelle from '@/components/MeetJenelle';
import Philosophy from '@/components/Philosophy';
import Insurance from '@/components/Insurance';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import { Helmet } from 'react-helmet-async';

const Index = () => {
  useEffect(() => {
    // Set up intersection observer for animations
    const observerOptions = {
      root: null,
      threshold: 0.1,
      rootMargin: '-50px'
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const elements = entry.target.querySelectorAll('.animate-on-scroll');
          elements.forEach((el, i) => {
            setTimeout(() => {
              (el as HTMLElement).classList.add('visible');
            }, i * 100);
          });
        }
      });
    }, observerOptions);

    // Observe all sections
    document.querySelectorAll('section').forEach((section) => {
      observer.observe(section);
    });

    return () => {
      // Clean up observer
      document.querySelectorAll('section').forEach((section) => {
        observer.unobserve(section);
      });
    };
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Mindful Nutrition and Wellness | Registered Dietitian in Chelmsford, MA</title>
        <meta name="description" content="Personalized nutrition counseling and wellness services in Chelmsford, MA. Our registered dietitian provides balanced meal planning, weight management, and holistic wellness approaches." />
        <meta name="keywords" content="dietitian, nutritionist, Chelmsford, Massachusetts, nutrition counseling, balanced meals, personalized meal plans, weight management, wellness, healthy eating, food relationship, registered dietitian nutritionist" />
        <meta property="og:title" content="Mindful Nutrition and Wellness | Registered Dietitian in Chelmsford, MA" />
        <meta property="og:description" content="Personalized nutrition counseling and wellness services in Chelmsford, MA. Our registered dietitian provides balanced meal planning, weight management, and holistic wellness approaches." />
        <meta property="og:type" content="website" />
        <meta property="og:image" content="/lovable-uploads/aa19bb0b-f9c8-454e-9401-7d79b5896798.png" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content="Mindful Nutrition and Wellness | Registered Dietitian in Chelmsford, MA" />
        <meta name="twitter:description" content="Personalized nutrition counseling and wellness services in Chelmsford, MA. Our registered dietitian provides balanced meal planning, weight management, and holistic wellness approaches." />
        <meta name="twitter:image" content="/lovable-uploads/aa19bb0b-f9c8-454e-9401-7d79b5896798.png" />
        <link rel="canonical" href="https://mindfulnutritionservices.com" />
      </Helmet>
      <Navbar />
      <main>
        <Hero />
        <About />
        <Services />
        <Expertise />
        <MeetJenelle />
        <Philosophy />
        <Insurance />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
